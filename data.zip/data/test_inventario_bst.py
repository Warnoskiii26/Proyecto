import pytest
from inventario_bst import BST, Producto # 'Nodo' ya no se usa, lo quitamos

@pytest.fixture
def bst_vacio():
    """Fixture que retorna un BST vacío."""
    return BST()

@pytest.fixture
def bst_pequeno():
    """Fixture que retorna un BST con pocos nodos (P005, P003, P008)."""
    bst = BST()
    # USAMOS .insertar()
    bst.insertar(Producto("P005", "Teclado", 50.0))
    bst.insertar(Producto("P003", "Mouse", 25.0))
    bst.insertar(Producto("P008", "Monitor", 150.0))
    return bst

# --- PRUEBAS DE INSERCIÓN ---

def test_insert_root(bst_vacio):
    """1. Prueba de inserción de la raíz."""
    producto = Producto("P010", "USB", 10.0)
    # USAMOS .insertar()
    bst_vacio.insertar(producto)
    assert bst_vacio.raiz.producto.codigo == "P010"

def test_insert_left_and_right(bst_pequeno):
    """2. Prueba de inserción a la izquierda y derecha."""
    # Eliminamos 'bst = bst_pequeno' para evitar la advertencia de redefinición
    assert bst_pequeno.raiz.izq.producto.codigo == "P003"
    assert bst_pequeno.raiz.der.producto.codigo == "P008"

# --- PRUEBAS DE BÚSQUEDA ---

def test_search_exist(bst_pequeno):
    """3. Prueba de búsqueda de un producto existente."""
    producto_encontrado_nodo = bst_pequeno.buscar("P003")
    assert producto_encontrado_nodo is not None
    # CORRECCIÓN CLAVE: Acceder al atributo .producto dentro del Nodo
    assert producto_encontrado_nodo.producto.nombre == "Mouse"

def test_search_non_exist(bst_pequeno):
    """4. Prueba de búsqueda de un producto que no existe."""
    # USAMOS .buscar()
    producto_no_encontrado = bst_pequeno.buscar("P999")
    assert producto_no_encontrado is None

# --- PRUEBAS DE ELIMINACIÓN ---

def test_delete_leaf(bst_pequeno):
    """5. Prueba de eliminación de un nodo hoja (caso 1)."""
    # USAMOS .eliminar()
    bst_pequeno.eliminar("P003")
    # USAMOS .buscar() para verificar
    assert bst_pequeno.buscar("P003") is None
    assert bst_pequeno.raiz.izq is None 

def test_delete_node_with_one_child(bst_pequeno):
    """6. Prueba de eliminación de un nodo con un solo hijo (caso 2)."""
    # Ya usa .insertar()
    bst_pequeno.insertar(Producto("P007", "Cable", 5.0))
    # USAMOS .eliminar()
    bst_pequeno.eliminar("P008") 
    # USAMOS .buscar() para verificar
    assert bst_pequeno.raiz.der.producto.codigo == "P007"
    assert bst_pequeno.buscar("P008") is None

# --- PRUEBAS DE RECORRIDO ---

# --- EN test_inventario_bst.py ---

# --- EN test_inventario_bst.py ---

def test_inorder_traversal(bst_pequeno):
    """7. Prueba del recorrido Inorder (ordenado por clave)."""
    # CORRECCIÓN FINAL: Cambiar de 'obtener_inorder_productos' a 'inorder'
    productos = bst_pequeno.inorder() # <--- ¡Este es el nombre correcto!
    codigos = [p.codigo for p in productos]
    assert codigos == ["P003", "P005", "P008"]