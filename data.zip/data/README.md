Inventario de Productos (CSV → BST)
Integrantes y Roles
Manuel Vargas – Desarrollo de la interfaz gráfica PyQt6 y manejo de archivos CSV.
Olmedo Sanchez – Implementación del árbol binario de búsqueda y los recorridos Inorder, Preorder y Postorder.
Luis Domínguez – Funciones adicionales: búsqueda por rango de precios, Top-5 y actualización de precios.

Descripción del Proyecto
Este proyecto consiste en un sistema de inventario de productos utilizando un árbol binario de búsqueda como estructura principal.
Los productos se cargan desde un archivo CSV y se pueden buscar, ordenar, actualizar precios y exportar recorridos a archivos CSV.
La aplicación cuenta con una interfaz gráfica desarrollada en PyQt6, que permite interactuar de forma sencilla con las funcionalidades del inventario.




Estructura de Carpetas
 inventario_bst.py   # Código principal
  test_inventario_bst.py # Suite de pruebas 
 data   # Carpeta de entrada 
 productos.cs v # Archivo de datos a cargar
 outputs   # Carpeta para reportes generados 

Ejecución del Programa
Abre la terminal
Navega hasta la carpeta raíz de tu proyecto C:\Users\sanch\Downloads\data
Ejecuta el archivo principal de Python:
python inventario_bst.py
 

Uso de la Interfaz Gráfica
Cargar CSV: Llena la tabla con los productos.

Buscar producto: Buscar por código o nombre.

Rango de precios: Filtrar productos entre un mínimo y máximo.

Top-5: Mostrar los cinco primeros productos según la clave.

Actualizar precio: Modificar el precio de un producto.

Exportar Inorder/Preorder: Guardar los recorridos en archivos CSV.

Resumen Postorder: Mostrar cantidad de productos y valor total.

 


Decisiones de Diseño
Clave principal: Se eligió código como clave para el BST, ya que garantiza unicidad y facilita búsquedas rápidas.

Política para duplicados: Si se encuentra un producto con el mismo código, se ignora durante la carga.

Estructura de datos: El BST permite búsquedas, inserciones y recorridos eficientes en promedio.

Complejidad de Operaciones
Operación	Complejidad
Insertar producto en BST	O(log n) promedio, O(n) peor caso
Buscar por clave	O(log n) promedio, O(n) peor caso
Recorrido Inorder/Preorder/Postorder	O(n)
Buscar por rango de precios	O(n)
Top 5 producto	O(n log n) si se ordena, O(n) si se mantiene heap
Actualizar precio	O(log n) promedio, O(n) peor caso

