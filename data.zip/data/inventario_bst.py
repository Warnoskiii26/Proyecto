import sys
import csv
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLineEdit, QLabel, QTableWidget, QTableWidgetItem,
    QMessageBox
)
from typing import Optional, List

#CLASES DEL MODELO BST

class Producto:
    """Clase para representar un producto."""
    def __init__(self, codigo: str, nombre: str, precio: float):
        self.codigo = codigo
        self.nombre = nombre
        self.precio = float(precio)

    def __repr__(self):
        return f"Producto({self.codigo}, {self.nombre}, {self.precio:.2f})"

class Nodo:
    """Clase que representa un nodo en el BST."""
    def __init__(self, producto: Producto):
        self.producto = producto
        self.izq: Optional[Nodo] = None
        self.der: Optional[Nodo] = None

class BST:
    """Árbol Binario de Búsqueda para el inventario."""
    def __init__(self, clave="codigo"):
        self.raiz: Optional[Nodo] = None
        self.clave = clave

    def _get_key(self, obj):
        """Retorna la clave de ordenamiento (codigo o nombre) del objeto."""
        return getattr(obj, self.clave)

    def insertar(self, producto: Producto):
        """Inserta un producto. Si la clave es duplicada, actualiza el precio."""
        def _insert(n: Optional[Nodo], prod: Producto) -> Nodo:
            if not n:
                return Nodo(prod)
            k1 = self._get_key(prod)
            k2 = self._get_key(n.producto)
            
            if k1 < k2:
                n.izq = _insert(n.izq, prod)
            elif k1 > k2:
                n.der = _insert(n.der, prod)
            else:
             
                n.producto.precio = prod.precio
            return n
            
        self.raiz = _insert(self.raiz, producto)

    def buscar(self, valor: str) -> Optional[Nodo]:
        """Búsqueda por clave (código o nombre, según la configuración del BST)."""
        def _bus(n: Optional[Nodo], v: str) -> Optional[Nodo]:
            if not n:
                return None
            k = self._get_key(n.producto)
            if k == v:
                return n
            if v < k:
                return _bus(n.izq, v)
            else:
                return _bus(n.der, v)
        return _bus(self.raiz, valor)

   
    def _find_min(self, n: Nodo) -> Nodo:
        """Encuentra el nodo con el valor mínimo en el subárbol (sucesor inorder)."""
        current = n
        while current.izq is not None:
            current = current.izq
        return current

    def eliminar(self, valor: str) -> bool:
        """Elimina un nodo del BST por su clave."""
        def _elim(n: Optional[Nodo], v: str) -> Optional[Nodo]:
            if n is None:
                return None
            
            k = self._get_key(n.producto)
            
            if v < k:
                n.izq = _elim(n.izq, v)
            elif v > k:
                n.der = _elim(n.der, v)
            else:
              
                if n.izq is None:
                    return n.der
                elif n.der is None:
                    return n.izq
                
               
                temp = self._find_min(n.der)
                n.producto = temp.producto 
                n.der = _elim(n.der, self._get_key(temp.producto))
                
            return n

        raiz_anterior = self.raiz
        self.raiz = _elim(self.raiz, valor)
        return raiz_anterior is not None and self.raiz is not None


    # RECORRIDOS REQUERIDOS

    def inorder(self) -> List[Producto]:
        """Recorrido Inorder: inventario ordenado por clave."""
        res = []
        def _in(n: Optional[Nodo]):
            if n:
                _in(n.izq)
                res.append(n.producto)
                _in(n.der)
        _in(self.raiz)
        return res

    def preorder(self) -> List[Producto]:
        """Recorrido Preorder: export para reconstruir la estructura."""
        res = []
        def _pre(n: Optional[Nodo]):
            if n:
                res.append(n.producto)
                _pre(n.izq)
                _pre(n.der)
        _pre(self.raiz)
        return res

    def postorder(self) -> List[Producto]:
        """Recorrido Postorder: usado para resumen de totales."""
        res = []
        def _post(n: Optional[Nodo]):
            if n:
                _post(n.izq)
                _post(n.der)
                res.append(n.producto)
        _post(self.raiz)
        return res
    
    #FUNCIONES EXTRA

    def traverse_range_price(self, mn: float, mx: float) -> List[Producto]:
        """Extra 1: Búsqueda por rango de precios usando un recorrido Inorder modificado."""
        res = []
        def _rango(n: Optional[Nodo]):
            if n:
                _rango(n.izq) 
                
                if mn <= n.producto.precio <= mx:
                    res.append(n.producto)
                    
                _rango(n.der)
        _rango(self.raiz)
        return res

    def top_k_by_key(self, k: int = 5, reverse: bool = True) -> List[Producto]:
        """Extra 2: Top-5 por clave (usando Inorder y ordenamiento Python)."""
        data = self.inorder()
        return sorted(data, key=lambda p: self._get_key(p), reverse=reverse)[:k]

    def find_by_any_id(self, ident: str) -> Optional[Nodo]:
        """Función auxiliar para buscar por código O por nombre (usada en update/buscar_producto)."""
        def _upd(n: Optional[Nodo]):
            if not n:
                return None
            
            
            if self._get_key(n.producto) == ident:
                return n
            
            
            if self.clave == 'codigo' and n.producto.nombre == ident:
                return n
            if self.clave == 'nombre' and n.producto.codigo == ident:
                return n
                
         
            nodo = _upd(n.izq)
            if nodo:
                return nodo
            return _upd(n.der)
            
        return _upd(self.raiz)

#INTERFAZ GRÁFICA PYQT6 

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Inventario de Producto (BST por Código)")
        self.setMinimumSize(900, 650)
        self.bst = BST(clave="codigo")

        layout = QVBoxLayout()
        
        #1. Log y Entradas
        self.log = QLineEdit(); self.log.setReadOnly(True)
        layout.addWidget(QLabel("Mensajes del sistema:"))
        layout.addWidget(self.log)

        hlayout = QHBoxLayout()
        self.min_price = QLineEdit(); self.min_price.setPlaceholderText("Precio Min")
        self.max_price = QLineEdit(); self.max_price.setPlaceholderText("Precio Max")
        self.search_id_input = QLineEdit(); self.search_id_input.setPlaceholderText("Código/Nombre a buscar/eliminar/actualizar")
        self.update_price_input = QLineEdit(); self.update_price_input.setPlaceholderText("Nuevo precio")
        
        hlayout.addWidget(self.min_price)
        hlayout.addWidget(self.max_price)
        hlayout.addWidget(self.search_id_input)
        hlayout.addWidget(self.update_price_input)
        layout.addLayout(hlayout)
        
        # 2. Botones de Operación
        botones_operaciones = [
            ("Cargar CSV", self.load_csv),
            ("Buscar Producto", self.buscar_producto),
            ("Eliminar Producto", self.eliminar_producto),
            ("Actualizar Precio", self.update_price)
        ]
        h_op = QHBoxLayout()
        for texto, funcion in botones_operaciones:
            btn = QPushButton(texto)
            btn.clicked.connect(funcion)
            h_op.addWidget(btn)
        layout.addLayout(h_op)

        #3. Botones de Recorrido
        botones_extra = [
            ("Buscar por Rango de Precios", self.search_range),
            ("Top 5 por Código", self.show_topk),
            ("Exportar Inorder (Ordenado)", self.export_inorder),
            ("Exportar Preorder (Estructura)", self.export_preorder),
            ("Resumen Postorder (Total)", self.show_postorder_summary)
        ]
        h_extra = QHBoxLayout()
        for texto, funcion in botones_extra:
            btn = QPushButton(texto)
            btn.clicked.connect(funcion)
            h_extra.addWidget(btn)
        layout.addLayout(h_extra)


        #4. Tabla de productos
        self.table = QTableWidget()
        self.table.setColumnCount(3)
        self.table.setHorizontalHeaderLabels(["Codigo", "Nombre", "Precio"])
        layout.addWidget(self.table)

        container = QWidget()
        container.setLayout(layout)
        self.setCentralWidget(container)
        
    #Funciones auxiliares de GUI
    
    def append_log(self, msg):
        self.log.setText(msg)
        print(msg)

    def refresh_table(self, rows: Optional[List[Producto]] = None):
        """Refresca la tabla. Si rows es None, usa Inorder para la lista ordenada."""
        if rows is None:
            rows = self.bst.inorder()
            
        self.table.setRowCount(len(rows))
        for i, p in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(p.codigo))
            self.table.setItem(i, 1, QTableWidgetItem(p.nombre))
            self.table.setItem(i, 2, QTableWidgetItem(f"{p.precio:.2f}"))

    #FUNCIONES PRINCIPALES
  
    def load_csv(self):
        """Carga el BST desde productos.csv[cite: 73]."""
        file_path = "data/productos.csv"
        try:
            
            os.makedirs("data", exist_ok=True) 
            
            with open(file_path, newline='', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    
                    precio = float(row['precio']) if 'precio' in row and row['precio'] else 0.0
                    prod = Producto(row['codigo'], row['nombre'], precio)
                    self.bst.insertar(prod)
            self.append_log(f"Archivo CSV cargado correctamente. Clave: {self.bst.clave}")
            self.refresh_table()
        except FileNotFoundError:
            QMessageBox.critical(self, "Error", f"No se encontró el archivo: {file_path}. Cree la carpeta 'data/' con el archivo 'productos.csv'.")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo cargar el CSV: {e}")

    def buscar_producto(self):
        """Busca un producto por código o nombre (usando la función auxiliar find_by_any_id)."""
        ident = self.search_id_input.text().strip()
        if not ident:
            QMessageBox.warning(self, "Advertencia", "Ingrese código o nombre para buscar.")
            return

    
        node = self.bst.find_by_any_id(ident) 
        if node:
            self.refresh_table([node.producto])
            self.append_log(f"✅ Encontrado: {node.producto.codigo} | {node.producto.nombre} | {node.producto.precio:.2f}")
        else:
            QMessageBox.information(self, "No encontrado", f"No se encontró el producto '{ident}'.")
            self.append_log(f"❌ Producto '{ident}' no encontrado.")
            self.refresh_table()

    def eliminar_producto(self):
        """Elimina un producto por su clave de ordenamiento (código)."""
        ident = self.search_id_input.text().strip()
        if not ident:
            QMessageBox.warning(self, "Advertencia", "Ingrese el código del producto a eliminar.")
            return
        
        if self.bst.clave != 'codigo' and self.bst.clave != 'nombre':
            QMessageBox.critical(self, "Error", "La clave de eliminación debe ser 'codigo' o 'nombre'.")
            return

        if self.bst.eliminar(ident):
            self.append_log(f"✅ Producto con clave '{ident}' eliminado.")
            self.refresh_table()
        else:
            QMessageBox.information(self, "No encontrado", f"No se encontró el producto '{ident}' para eliminar.")
            self.append_log(f"❌ Error al eliminar producto '{ident}'.")

    def update_price(self):
        """Extra: Actualizar precio por código o nombre."""
        ident = self.search_id_input.text().strip()
        if not ident:
            QMessageBox.warning(self, "Advertencia", "Ingrese código o nombre.")
            return
        try:
            newp = float(self.update_price_input.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Ingrese un precio válido.")
            return
            
        node = self.bst.find_by_any_id(ident)
        if node:
            old = node.producto.precio
            node.producto.precio = newp
            self.refresh_table()
            self.append_log(f"✅ Precio actualizado: {node.producto.codigo} {node.producto.nombre} | {old:.2f} -> {newp:.2f}")
        else:
            QMessageBox.information(self, "No encontrado", "Producto no encontrado.")
            self.append_log(f"❌ Producto '{ident}' no encontrado para actualizar.")


    # EXPORTES Y RECORRIDOS (Inorder, Preorder, Postorder)

    def export_inorder(self):
        """Uso de Inorder: Exporta el inventario ordenado por clave."""
        try:
            os.makedirs("outputs", exist_ok=True)
            rows = self.bst.inorder()
            file_path = "outputs/inventario_ordenado.csv"
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(['codigo', 'nombre', 'precio'])
                for p in rows:
                    w.writerow([p.codigo, p.nombre, f"{p.precio:.2f}"])
            self.append_log(f"✅ Inorder (Ordenado) exportado a {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo exportar: {e}")

    def export_preorder(self):
        """Uso de Preorder: Exporta la secuencia para reconstruir."""
        try:
            os.makedirs("outputs", exist_ok=True)
            rows = self.bst.preorder()
            file_path = "outputs/inventario_preorder.csv"
            with open(file_path, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(['codigo', 'nombre', 'precio'])
                for p in rows:
                    w.writerow([p.codigo, p.nombre, f"{p.precio:.2f}"])
            self.append_log(f"✅ Preorder (Estructura) exportado a {file_path}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"No se pudo exportar: {e}")

    def show_postorder_summary(self):
        """Uso de Postorder: Calcula el resumen de totales."""
        rows = self.bst.postorder()
        total = sum(p.precio for p in rows)
        count = len(rows)
        
        os.makedirs("outputs", exist_ok=True)
        file_path = "outputs/resumen_postorder.txt"
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(f"Resumen Postorder (Totales)\n")
            f.write(f"Productos: {count}\n")
            f.write(f"Valor total: {total:.2f}\n")
            
        self.append_log(f"✅ Postorder completado ({count} productos, total={total:.2f}). Resumen guardado en {file_path}")
        QMessageBox.information(self, "Resumen Postorder", f"Productos: {count}\nValor total: {total:.2f}")

    def search_range(self):
        """Extra: Rango de precios [min, max] usando recorrido."""
        try:
            mn = float(self.min_price.text())
            mx = float(self.max_price.text())
        except ValueError:
            QMessageBox.warning(self, "Error", "Ingrese valores válidos para el rango.")
            return
        if mn > mx:
            QMessageBox.warning(self, "Error", "El precio mínimo debe ser menor o igual al máximo.")
            return
            
        rows = self.bst.traverse_range_price(mn, mx)
        self.refresh_table(rows)
        self.append_log(f"✅ Productos entre ${mn:.2f} y ${mx:.2f}: {len(rows)} encontrados")

    def show_topk(self):
        """Extra: Top-5 por la clave del BST."""
        rows = self.bst.top_k_by_key(k=5, reverse=True)
        self.refresh_table(rows)
        self.append_log("✅ Mostrando Top 5 productos por clave (mayor código primero).")


#EJECUCIÓN

if __name__ == "__main__":

    
    app = QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())